# Security Policy

DeSo encourages responsible vulnerability disclosure for security issues.

Read the [Bug Bounty documentation](https://docs.deso.org/devs/bug-bounty) for more information.
