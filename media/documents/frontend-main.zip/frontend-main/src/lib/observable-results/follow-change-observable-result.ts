export class FollowChangeObservableResult {
  public followedPubKeyBase58Check: string;
  public isFollowing: boolean;
}
